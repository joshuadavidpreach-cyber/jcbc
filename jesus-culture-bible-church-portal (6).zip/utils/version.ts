
export const APP_VERSION = "5.7.0";
export const SYSTEM_STATUS = "STABLE";
export const BUILD_CODENAME = "JGLM-RECOVERY-FINAL";
export const DEPLOY_DATE = new Date().toISOString().split('T')[0];
